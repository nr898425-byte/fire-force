// ================================================
//  FIRE FORCE - Game Server (Node.js + Express + Socket.io)
//  Setup:  npm init -y  ->  npm install express socket.io  ->  node server.js
// ================================================
const express = require('express');
const http = require('http');
const path = require('path');
const crypto = require('crypto');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || crypto.randomBytes(8).toString('hex');
const MAX_PLAYERS = 10;
const MAP = 1200;
const TICK_MS = 50;            // 20 updates per second
const SPEED = 5;
const RANGE = 380;
const HIT_RADIUS = 22;
const DAMAGE = 25;
const FIRE_COOLDOWN = 330;     // ms
const ZONE_MIN = 60;
const ZONE_SHRINK = 0.5;       // per tick (zone dheere-dheere chhota hota hai)
const ZONE_DAMAGE = 0.25;      // hp per tick zone ke bahar
const COLORS = ['#ff595e', '#1982c4', '#8ac926', '#ffca3a', '#6a4c93',
  '#ff924c', '#00bbf9', '#f15bb5', '#43aa8b', '#9b5de5'];

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

let serverOn = true;
const rooms = new Map();

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));
app.get('/status', (req, res) => res.json({ on: serverOn, rooms: rooms.size }));

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const freshZone = () => ({ x: MAP / 2, y: MAP / 2, r: MAP / 2 });

function makeRoom(id) {
  return { id, status: 'lobby', hostId: null, timer: null, zone: freshZone(), players: new Map(), feed: [] };
}

function destroyRoom(room) {
  clearInterval(room.timer);
  rooms.delete(room.id);
}

function addFeed(room, text) {
  room.feed.push(text);
  if (room.feed.length > 20) room.feed.shift();
}

function spawnPoint(room) {
  const a = Math.random() * Math.PI * 2;
  const d = Math.random() * (room.zone.r - 60);
  return { x: room.zone.x + Math.cos(a) * d, y: room.zone.y + Math.sin(a) * d };
}

function publicPlayers(room) {
  const now = Date.now();
  return [...room.players.values()].map(p => ({
    id: p.id, name: p.name, color: p.color, x: p.x, y: p.y, angle: p.angle,
    hp: Math.max(0, Math.round(p.hp)), kills: p.kills,
    alive: p.alive, jumping: p.jumpUntil > now
  }));
}

function killPlayer(room, victim, killer) {
  victim.alive = false;
  victim.hp = 0;
  if (killer) killer.kills++;
  addFeed(room, killer ? `${killer.name} ➜ ${victim.name}` : `${victim.name} zone mein mar gaya`);
  io.to(victim.id).emit('died', { by: killer ? killer.name : 'ZONE' });
  checkWin(room);
}

// Jab sirf 1 player bacha ho -> BOOYAH!
function checkWin(room) {
  if (room.status !== 'playing') return;
  const all = [...room.players.values()];
  const alive = all.filter(p => p.alive);
  if (alive.length > 1) return;
  room.status = 'ended';
  const winner = alive[0] || all.sort((a, b) => b.kills - a.kills)[0];
  if (winner) addFeed(room, `BOOYAH! ${winner.name}`);
  io.to(room.id).emit('booyah', {
    winnerId: winner ? winner.id : null,
    winner: winner ? winner.name : 'Nobody',
    kills: winner ? winner.kills : 0
  });
}

function tick(room) {
  if (room.status === 'playing') {
    room.zone.r = Math.max(ZONE_MIN, room.zone.r - ZONE_SHRINK);
  }
  for (const p of room.players.values()) {
    if (!p.alive) continue;
    p.x = clamp(p.x + p.dx * SPEED, 0, MAP);
    p.y = clamp(p.y + p.dy * SPEED, 0, MAP);
    if (room.status === 'playing' && Math.hypot(p.x - room.zone.x, p.y - room.zone.y) > room.zone.r) {
      p.hp -= ZONE_DAMAGE;
      if (p.hp <= 0) killPlayer(room, p, null);
    }
  }
  io.to(room.id).emit('state', {
    status: room.status, hostId: room.hostId, zone: room.zone,
    players: publicPlayers(room), feed: room.feed.slice(-4)
  });
}

function setServer(on) {
  serverOn = on;
  if (!on) {
    for (const room of [...rooms.values()]) {
      io.socketsLeave(room.id);
      destroyRoom(room);
    }
    for (const s of io.sockets.sockets.values()) s.data.roomId = null;
  }
  io.emit('server:status', { on: serverOn });
  console.log(`>>> Server is ${serverOn ? 'ON' : 'OFF'}`);
}

io.on('connection', (socket) => {
  socket.data.roomId = null;
  socket.emit('server:status', { on: serverOn });

  const ctx = () => {
    const room = socket.data.roomId && rooms.get(socket.data.roomId);
    const p = room && room.players.get(socket.id);
    return p ? { room, p } : null;
  };

  function leave() {
    const id = socket.data.roomId;
    if (!id) return;
    socket.data.roomId = null;
    socket.leave(id);
    const room = rooms.get(id);
    if (!room) return;
    const p = room.players.get(socket.id);
    room.players.delete(socket.id);
    if (p) addFeed(room, `${p.name} chala gaya`);
    if (room.players.size === 0) return destroyRoom(room);
    if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
    checkWin(room);
  }

  socket.on('join', (data, cb) => {
    if (typeof cb !== 'function') return;
    if (!serverOn) return cb({ ok: false, msg: 'Server OFF hai' });
    if (socket.data.roomId) return cb({ ok: false, msg: 'Pehle room se bahar aao' });
    const roomId = String(data?.room || '').trim().toUpperCase().slice(0, 8);
    const name = String(data?.name || '').trim().slice(0, 12) || 'Player';
    if (!roomId) return cb({ ok: false, msg: 'Room ID daalo' });

    let room = rooms.get(roomId);
    if (!room) { room = makeRoom(roomId); rooms.set(roomId, room); }
    if (room.status === 'playing') return cb({ ok: false, msg: 'Match chal raha hai, thoda wait karo' });
    if (room.players.size >= MAX_PLAYERS) return cb({ ok: false, msg: 'Room full (10/10)' });

    if (room.status !== 'playing') room.zone = freshZone();
    const used = new Set([...room.players.values()].map(p => p.color));
    const color = COLORS.find(c => !used.has(c));
    const sp = spawnPoint(room);
    room.players.set(socket.id, {
      id: socket.id, name, color, x: sp.x, y: sp.y, angle: 0, dx: 0, dy: 0,
      hp: 100, kills: 0, alive: true, jumpUntil: 0, lastShot: 0
    });
    if (!room.hostId) room.hostId = socket.id;
    socket.join(room.id);
    socket.data.roomId = room.id;
    addFeed(room, `${name} join kiya`);
    if (!room.timer) room.timer = setInterval(() => tick(room), TICK_MS);
    cb({ ok: true, id: socket.id, roomId: room.id, color });
  });

  socket.on('input', (d) => {
    const c = ctx();
    if (!c || !c.p.alive || !d) return;
    c.p.dx = clamp(Number(d.dx) || 0, -1, 1);
    c.p.dy = clamp(Number(d.dy) || 0, -1, 1);
    if (Number.isFinite(d.angle)) c.p.angle = d.angle;
  });

  socket.on('jump', () => {
    const c = ctx();
    if (c && c.p.alive) c.p.jumpUntil = Date.now() + 600;
  });

  socket.on('fire', () => {
    const c = ctx();
    if (!c || c.room.status !== 'playing' || !c.p.alive) return;
    const { room, p: s } = c;
    const now = Date.now();
    if (now - s.lastShot < FIRE_COOLDOWN) return;
    s.lastShot = now;
    io.to(room.id).emit('shot', { x: s.x, y: s.y, angle: s.angle, range: RANGE });

    let target = null, best = Infinity;
    for (const t of room.players.values()) {
      if (t === s || !t.alive || t.jumpUntil > now) continue;
      const dx = t.x - s.x, dy = t.y - s.y;
      const dist = Math.hypot(dx, dy);
      if (dist > RANGE) continue;
      let diff = Math.atan2(dy, dx) - s.angle;
      diff = Math.atan2(Math.sin(diff), Math.cos(diff));
      if (Math.abs(diff) > Math.PI / 2) continue;
      if (Math.abs(dist * Math.sin(diff)) <= HIT_RADIUS && dist < best) {
        best = dist;
        target = t;
      }
    }
    if (target) {
      target.hp -= DAMAGE;
      io.to(target.id).emit('hitYou', { by: s.name });
      if (target.hp <= 0) killPlayer(room, target, s);
    }
  });

  socket.on('start', () => {
    const c = ctx();
    if (!c || c.room.hostId !== socket.id || c.room.status === 'playing') return;
    const { room } = c;
    if (room.players.size < 2) return socket.emit('toast', 'Kam se kam 2 players chahiye');
    room.status = 'playing';
    room.zone = freshZone();
    room.feed = [];
    for (const p of room.players.values()) {
      const sp = spawnPoint(room);
      Object.assign(p, { x: sp.x, y: sp.y, hp: 100, kills: 0, alive: true, dx: 0, dy: 0, jumpUntil: 0 });
    }
    addFeed(room, 'Match shuru! Zone chhota ho raha hai');
    io.to(room.id).emit('toast', '🔥 MATCH START!');
  });

  socket.on('leave', leave);
  socket.on('disconnect', leave);

  // Server ON / OFF (admin key se)
  socket.on('admin:toggle', (d, cb) => {
    if (typeof cb !== 'function') return;
    if (!d || d.key !== ADMIN_KEY) return cb({ ok: false, msg: 'Admin key galat hai' });
    setServer(!serverOn);
    cb({ ok: true, on: serverOn });
  });
});

// Terminal se bhi: 'off' / 'on' / 'status'
process.stdin.on('data', buf => {
  const cmd = buf.toString().trim().toLowerCase();
  if (cmd === 'on') setServer(true);
  else if (cmd === 'off') setServer(false);
  else if (cmd === 'status') console.log(`Server ${serverOn ? 'ON' : 'OFF'} | rooms: ${rooms.size}`);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`🔥 FIRE FORCE server chal raha hai | port ${PORT} | host 0.0.0.0`);
  if (process.env.ADMIN_KEY) {
    console.log('Admin key: ADMIN_KEY environment variable se set hai');
  } else {
    console.log(`⚠ ADMIN_KEY set nahi hai. Is restart ke liye temporary key: ${ADMIN_KEY}`);
    console.log('  Hosting par ADMIN_KEY environment variable zaroor set karo.');
  }
});
